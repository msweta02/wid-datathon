# %% [markdown]
# # 03 — QI: Production Indices
#
# QI normalizes production to a base period (2014–2016 = 100), so it's the cleanest
# way to compare **trends** across countries of very different sizes. Also has
# per-capita indices — directly relevant to food security framing.
#
# Questions:
# - Which regions have rising vs falling per-capita production? (food-security signal)
# - Does the index confirm the raw-QCL story, or diverge (base-period / composition effects)?

# %%
import sys
from pathlib import Path
sys.path.append(str(Path.cwd().parent if Path.cwd().name == "notebooks" else Path.cwd()))

import pandas as pd
import matplotlib.pyplot as plt

from src.load import load_dataset, load_codes
from src.clean import standardize_columns, split_aggregates, resolve_china, data_quality_report
from src.viz import trend_over_time, save

# %% [markdown]
# ## 1. Load QI and inspect elements — pick gross PIN and per-capita PIN

# %%
qi_full = standardize_columns(load_dataset("QI"))
print(qi_full[["element_code", "element", "unit"]].drop_duplicates().to_string(index=False))

# %% [markdown]
# ## 2. Inspect items, then filter to a broad food aggregate
# Item like "Agriculture" or "Crops" (verify exact name below). Keep the
# Gross PIN and per-capita PIN elements.

# %%
print(qi_full[["item_code", "item"]].drop_duplicates().head(30).to_string(index=False))

# %%
# Adjust these to the exact strings shown above:
QI_ITEMS = ["Agriculture"]
QI_ELEMENTS = qi_full[qi_full["element"].str.contains("capita|Gross Production Index", case=False, na=False)]["element"].unique().tolist()
print("matched elements:", QI_ELEMENTS)

qi = qi_full[qi_full["item"].isin(QI_ITEMS) & qi_full["element"].isin(QI_ELEMENTS)].copy()
qi.head()

# %% [markdown]
# ## 3. Quality + coverage

# %%
for k, v in data_quality_report(qi).items():
    print(f"{k}: {v}")

# %%
countries, aggregates = split_aggregates(qi)
countries = resolve_china(countries)

# %% [markdown]
# ## 4. Regional trends from the aggregates table
# The aggregates frame contains World / continents / income groups — perfect for a
# clean regional-shift picture without summing countries yourself.

# %%
per_capita = aggregates[aggregates["element"].str.contains("capita", case=False, na=False)]
fig, ax = trend_over_time(per_capita, "year", "value", group_col="area",
                          title="Per-capita production index by region",
                          ylabel="Index (2014-16 = 100)")
save(fig, "qi_percapita_by_region")
plt.show()

# %% [markdown]
# ## 5. Rising vs falling countries (latest year vs a decade ago)

# %%
def change_vs_decade(frame, element_kw="capita"):
    sub = frame[frame["element"].str.contains(element_kw, case=False, na=False)]
    latest = int(sub["year"].max())
    a = sub[sub["year"] == latest].set_index("area")["value"]
    b = sub[sub["year"] == latest - 10].set_index("area")["value"]
    change = (a - b).dropna().sort_values()
    return change, latest

change, latest = change_vs_decade(countries)
print(f"Biggest 10-year DROPS in per-capita production index (as of {latest}):")
print(change.head(15))
print("\nBiggest RISES:")
print(change.tail(15))

# %% [markdown]
# **Checkpoint:** QI is low-effort, high-signal for a food-security angle. Note whether
# it tells the same story as QCL or reveals something QCL's raw tonnage hides.
