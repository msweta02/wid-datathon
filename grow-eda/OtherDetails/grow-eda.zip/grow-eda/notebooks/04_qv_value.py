# %% [markdown]
# # 04 — QV: Value of Agricultural Production
#
# QV adds the **economic** dimension: which crops/countries generate the most value,
# and how value-per-tonne (a rough price/quality proxy) shifts. Pairing QV with QCL
# lets you separate "grows a lot of cheap calories" from "grows high-value crops."
#
# Questions:
# - Does production volume (QCL) track economic value (QV), or are they decoupled?
# - Which crops are rising in value share? (economic-shift hypothesis)

# %%
import sys
from pathlib import Path
sys.path.append(str(Path.cwd().parent if Path.cwd().name == "notebooks" else Path.cwd()))

import pandas as pd
import matplotlib.pyplot as plt

from src.load import load_dataset, load_codes
from src.clean import standardize_columns, split_aggregates, resolve_china, data_quality_report
from src.viz import trend_over_time, save

# %% [markdown]
# ## 1. Load QV and inspect elements — prefer constant-price (int'l $) for cross-time comparison

# %%
qv_full = standardize_columns(load_dataset("QV"))
print(qv_full[["element_code", "element", "unit"]].drop_duplicates().to_string(index=False))

# %% [markdown]
# ## 2. Filter to the same staples as notebook 02, using a constant-price element
# Pick a "Gross Production Value (constant ... I$)" element from the list above.

# %%
STAPLES = ["Wheat", "Rice", "Maize (corn)"]   # match notebook 02 spelling
VALUE_ELEMENT = "Gross Production Value (constant 2014-2016 thousand I$)"  # adjust to what's listed

qv = qv_full[qv_full["item"].isin(STAPLES)]
qv = qv[qv["element"] == VALUE_ELEMENT].copy() if VALUE_ELEMENT in qv["element"].unique() else qv
print("elements kept:", qv["element"].unique().tolist())
qv.head()

# %% [markdown]
# ## 3. Quality

# %%
for k, v in data_quality_report(qv).items():
    print(f"{k}: {v}")

# %%
countries, aggregates = split_aggregates(qv)
countries = resolve_china(countries)

# %% [markdown]
# ## 4. Global value trend by crop

# %%
fig, ax = trend_over_time(countries, "year", "value", group_col="item",
                          title="Value of production — staple crops",
                          ylabel="Gross Production Value")
save(fig, "qv_value_by_crop")
plt.show()

# %% [markdown]
# ## 5. Value vs Volume — are they decoupling?
# Join QV value with QCL production and look at value-per-tonne over time.
# Requires the QCL staples_full cache from notebook 02.

# %%
qcl = standardize_columns(load_dataset("QCL"))
qcl = qcl[qcl["item"].isin(STAPLES)]
qcl_prod = qcl[qcl["element"].str.contains("Production", na=False)]

merged = (
    countries.groupby(["area", "item", "year"])["value"].sum().rename("value_usd").reset_index()
    .merge(
        qcl_prod.groupby(["area", "item", "year"])["value"].sum().rename("prod_t").reset_index(),
        on=["area", "item", "year"], how="inner",
    )
)
merged["value_per_tonne"] = merged["value_usd"] / merged["prod_t"].replace(0, pd.NA)

world = merged.groupby(["item", "year"])["value_per_tonne"].median().reset_index()
fig, ax = plt.subplots(figsize=(10, 6))
for item, g in world.groupby("item"):
    ax.plot(g["year"], g["value_per_tonne"], label=item)
ax.set_title("Median value per tonne over time (value/volume decoupling)")
ax.set_ylabel("value per tonne")
ax.legend()
save(fig, "qv_value_per_tonne")
plt.show()

# %% [markdown]
# **Checkpoint:** QV is the differentiator — most datathon teams stop at volume.
# An economic angle (value shifting faster than volume) is a strong, less-obvious hypothesis.
