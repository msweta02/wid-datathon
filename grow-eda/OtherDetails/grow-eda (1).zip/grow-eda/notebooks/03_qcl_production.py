# %% [markdown]
# # 03 — QCL: Production, Yield & Area
#
# The heart of GROW. Questions we want to answer:
# - Which crops/regions dominate production, and how has that shifted since 1961?
# - Is growth driven by **more land** (area) or **better yield**? (This is a great hypothesis seed.)
# - Where is production *declining* — candidate "regions at risk" for the forecast project.

# %%
import sys
from pathlib import Path
sys.path.append(str(Path.cwd().parent if Path.cwd().name == "notebooks" else Path.cwd()))

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from src.load import load_dataset
from src.clean import (standardize_columns, split_aggregates, resolve_china,
                       annotate_flags, data_quality_report)
from src.viz import trend_over_time, missingness_heatmap, flag_composition, save

# %% [markdown]
# ## 1. Load QCL (full) and filter to a working slice in pandas
# Bulk loading gives the whole dataset; we filter to staples + the three physical
# elements. Verify the Item/Element names against notebook 01's inventory.

# %%
qcl = standardize_columns(load_dataset("QCL"))

STAPLES = ["Wheat", "Rice", "Maize (corn)"]   # check exact spelling in notebook 01
ELEMENTS = ["Production", "Yield", "Area harvested"]

df = qcl[qcl["item"].isin(STAPLES) & qcl["element"].isin(ELEMENTS)].copy()
print(f"filtered: {df.shape}")
print("items found:", df['item'].unique().tolist())
print("elements found:", df['element'].unique().tolist())
df.head()

# %% [markdown]
# ## 2. Split aggregates from countries, resolve China

# %%
countries, aggregates = split_aggregates(df)
countries = resolve_china(countries)
countries = annotate_flags(countries)
print(f"country rows: {len(countries):,} | aggregate rows: {len(aggregates):,}")

# %% [markdown]
# ## 3. Data quality — is this even usable? (feasibility)

# %%
report = data_quality_report(countries)
for k, v in report.items():
    print(f"{k}: {v}")

# %%
# How much of the data is estimated/imputed vs official, over time?
fig, ax = flag_composition(countries, title="QCL staples — flag composition over time")
save(fig, "qcl_flag_composition")
plt.show()

# %% [markdown]
# ## 4. Global production trend by crop

# %%
prod = countries[countries["element"].str.contains("Production", case=False, na=False)]
fig, ax = trend_over_time(prod, "year", "value", group_col="item",
                          title="Global production of staple crops (country sum)",
                          ylabel="Production (tonnes)")
save(fig, "qcl_global_production_by_crop")
plt.show()

# %% [markdown]
# ## 5. Area vs Yield decomposition — WHY is production changing?
# Production = Area x Yield. Comparing the two curves tells the story:
# intensification (yield) vs expansion (area). Strong hypothesis material.

# %%
def decomposition(crop_item: str):
    sub = countries[countries["item"] == crop_item]
    area = sub[sub["element"].str.contains("Area", na=False)].groupby("year")["value"].sum()
    yld = sub[sub["element"].str.contains("Yield", na=False)].groupby("year")["value"].mean()
    prod = sub[sub["element"].str.contains("Production", na=False)].groupby("year")["value"].sum()

    fig, axes = plt.subplots(1, 3, figsize=(16, 4))
    for a, series, name in zip(axes, [prod, area, yld],
                               ["Production (t)", "Area harvested (ha)", "Yield (hg/ha, mean)"]):
        # index to first year = 100 for comparability
        idx = series / series.iloc[0] * 100
        a.plot(idx.index, idx.values)
        a.set_title(f"{crop_item} — {name}")
        a.set_ylabel("index (first year = 100)")
        a.axhline(100, color="grey", ls="--", lw=0.8)
    fig.tight_layout()
    return fig

for crop in countries["item"].unique():
    fig = decomposition(crop)
    save(fig, f"qcl_decomposition_{crop.lower()}")
    plt.show()

# %% [markdown]
# ## 6. Where is production DECLINING?
# Compute per-country CAGR of production over the last ~20 years. Negative = at risk.
# These are exactly the "regions at risk of decline" the GROW project example calls for.

# %%
def cagr_by_country(crop_item: str, element_kw: str = "Production", last_n: int = 20):
    sub = countries[(countries["item"] == crop_item) &
                    (countries["element"].str.contains(element_kw, na=False))]
    latest = int(sub["year"].max())
    window = sub[sub["year"] >= latest - last_n]
    out = []
    for area, g in window.groupby("area"):
        g = g.sort_values("year")
        first, last = g["value"].iloc[0], g["value"].iloc[-1]
        yrs = g["year"].iloc[-1] - g["year"].iloc[0]
        if first and first > 0 and yrs > 0:
            cagr = (last / first) ** (1 / yrs) - 1
            out.append({"area": area, "cagr": cagr, "latest_value": last})
    res = pd.DataFrame(out).sort_values("cagr")
    return res

decline = cagr_by_country("Wheat")
print("Fastest-declining wheat producers (by CAGR, last 20y):")
decline.head(15)

# %% [markdown]
# ## 7. Yield gap — how much headroom is there?
# For a staple, compare the yield of top vs bottom producers in the latest year.
# A wide gap between the frontier and the laggards = large potential gains from
# closing it, which is a strong, actionable GROW story (and pairs with food security).

# %%
def yield_gap(crop_item: str, min_area_ha: float = 10000):
    latest = int(countries["year"].max())
    y = countries[(countries["item"] == crop_item) &
                  (countries["element"].str.contains("Yield", na=False)) &
                  (countries["year"] == latest)]
    a = countries[(countries["item"] == crop_item) &
                  (countries["element"].str.contains("Area", na=False)) &
                  (countries["year"] == latest)][["area", "value"]].rename(columns={"value": "area_ha"})
    m = y.merge(a, on="area", how="left")
    # only meaningful producers (avoid tiny plots with noisy yields)
    m = m[m["area_ha"] >= min_area_ha].copy()
    m = m.sort_values("value", ascending=False)
    return m, latest

gap, yr = yield_gap("Wheat")
print(f"Wheat yield ({yr}) — top 5 vs bottom 5 among meaningful producers (kg/ha):")
print("TOP:\n", gap[["area", "value"]].head(5).to_string(index=False))
print("\nBOTTOM:\n", gap[["area", "value"]].tail(5).to_string(index=False))
if len(gap):
    frontier = gap["value"].quantile(0.9)
    median = gap["value"].median()
    print(f"\n90th-pct frontier yield: {frontier:,.0f} kg/ha | median: {median:,.0f} kg/ha")
    print(f"Gap ratio (frontier/median): {frontier/median:.1f}x")

# %%
fig, ax = plt.subplots(figsize=(10, 5))
ax.hist(gap["value"].dropna(), bins=30, color="#4c8c5a", edgecolor="white")
ax.axvline(gap["value"].median(), color="black", ls="--", lw=1, label="median")
ax.axvline(gap["value"].quantile(0.9), color="crimson", ls="--", lw=1, label="90th pct (frontier)")
ax.set_xlabel("Yield (kg/ha)")
ax.set_ylabel("number of countries")
ax.set_title(f"Wheat yield distribution across countries ({yr}) — the gap to close")
ax.legend()
save(fig, "qcl_wheat_yield_gap")
plt.show()

# %% [markdown]
# ## 8. Regional shift — is production moving between continents?
# Uses the aggregates frame (continents are pre-computed by FAOSTAT, no summing
# countries). Share of world staple production by region over time answers the
# brief's core question directly: "how is production shifting across regions?"

# %%
CONTINENTS = ["Africa", "Americas", "Asia", "Europe", "Oceania"]
reg = aggregates[(aggregates["area"].isin(CONTINENTS)) &
                 (aggregates["element"].str.contains("Production", na=False))]

for crop in reg["item"].unique():
    sub = reg[reg["item"] == crop]
    pivot = sub.pivot_table(index="year", columns="area", values="value", aggfunc="sum")
    share = pivot.div(pivot.sum(axis=1), axis=0) * 100
    fig, ax = plt.subplots(figsize=(11, 5))
    share.plot.area(ax=ax, linewidth=0)
    ax.set_title(f"{crop} — share of world production by region (%)")
    ax.set_ylabel("% of world production")
    ax.set_xlabel("Year")
    ax.legend(bbox_to_anchor=(1.02, 1), loc="upper left", fontsize=8)
    ax.margins(x=0)
    save(fig, f"qcl_regional_share_{crop.lower().replace(' ', '_').replace('(', '').replace(')', '')}")
    plt.show()

# %% [markdown]
# **Checkpoint:** Notes for synthesis —
# - Is coverage good enough? (step 3 — flags mostly official?)
# - Which crop shows the most interesting area/yield story? (step 5)
# - Which regions are declining and worth a forecast/flag project? (step 6)
# - How big is the yield gap, and which laggards have the most headroom? (step 7)
# - Which continent is gaining/losing production share, and for which crop? (step 8)
