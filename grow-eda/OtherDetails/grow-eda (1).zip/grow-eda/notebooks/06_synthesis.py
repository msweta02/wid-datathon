# %% [markdown]
# # 06 — Synthesis: Go/No-Go + Candidate Hypotheses
#
# Pull the threads from 02–04 into a decision. This notebook is mostly a structured
# template you fill in as you run the others — the datathon deliverable starts here.

# %%
import sys
from pathlib import Path
sys.path.append(str(Path.cwd().parent if Path.cwd().name == "notebooks" else Path.cwd()))

import pandas as pd
from src.load import load_dataset
from src.clean import standardize_columns, data_quality_report

# %% [markdown]
# ## 1. Feasibility scorecard
# Fill each field from the quality reports you ran. Rough rubric below.

# %%
feasibility = {
    "coverage_years": "1961–latest (60+ yrs)  — STRONG",
    "country_coverage": "~200 countries + aggregates — STRONG",
    "missingness": "TODO from data_quality_report (pct_missing_value)",
    "estimated_imputed_share": "TODO from flag_composition — note if heavy pre-1990",
    "data_access": "bulk CSV, melt+parquet cache in place — EASY",
    "china_aggregate_traps": "handled in clean.py — LOW risk once aware",
    "unit_pitfalls": "yield in hg/ha; value price-basis choice — MANAGEABLE",
}
for k, v in feasibility.items():
    print(f"- {k}: {v}")

# %% [markdown]
# ### Go / No-Go call
#
# > **Verdict (fill in):** GROW is / isn't a good track because ...
# >
# > The data is rich and clean enough that the bottleneck is *framing a sharp question*,
# > not wrangling. That favors GO — the risk is scope, not feasibility.

# %% [markdown]
# ## 2. Candidate hypotheses (rank these with your team)
#
# From the three datasets, the strongest angles that emerged:
#
# 1. **Intensification vs expansion** (QCL, notebook 03 step 5):
#    "Since 2000, staple production growth in [region] is driven by yield gains, while
#    [other region] still expands cropland — with implications for [emissions/food security]."
#    → Project: decompose + forecast which regions hit a yield ceiling.
#
# 2. **Regions at risk of decline** (QCL, notebook 03 step 6):
#    "[N] countries show negative production CAGR for [crop] over 20 years."
#    → Project: forecast crop yields for a key staple and flag at-risk regions
#      (matches the GROW example brief exactly).
#
# 3. **Per-capita food-production divergence** (QI, notebook 04):
#    "Per-capita production is falling in [region] even as total rises — a food-security gap."
#    → Project: food-security-flavored dashboard, pairs well with the EAT track if you pivot.
#
# 4. **Value/volume decoupling** (QV + QCL, notebook 05):
#    "Economic value of [crop] is rising faster than volume — a shift toward higher-value
#    agriculture in [region]." → Less obvious, differentiates from other teams.
#
# 5. **Production concentration / supply-shock risk** (QCL, notebook 02 step 6):
#    "[N] of the top-10 global commodities have >X% of production in a single country —
#    a shock there (drought, conflict, policy) ripples worldwide."
#    → Project: rank commodities by concentration, model a supply-shock scenario
#      (matches the TRADE example too — good cross-track bridge).
#
# 6. **Yield-gap opportunity** (QCL, notebook 03 step 7):
#    "For [staple], laggard countries sit at a fraction of the frontier yield —
#    closing the gap would add [X] Mt without new cropland."
#    → Project: map the gap, prioritise where headroom + food-insecurity overlap.
#
# 7. **Production-side vulnerability** (QCL + QI, notebook 07 — trade-flavored, GROW-only):
#    "The most globally concentrated staples (HHI > 2500, one country holding >X% of
#    world output) are also consumed by regions with FALLING per-capita production —
#    fragile supply meeting rising import need."
#    → Project: a production-side vulnerability ranking (concentration × self-sufficiency
#      loss) that a TRADE team's import-side score could be laid against — same crops,
#      same countries, two lenses. Standalone GROW, but built for an easy comparison.
#
# Pick ONE as primary. #2 is the safest match to the brief; #4 is the most distinctive;
# #5 bridges cleanly to TRADE; #6 is the most food-security-positive framing.

# %% [markdown]
# ## 3. Scope recommendation
# Based on the broad scan, narrow to:
# - **Crops:** the 1–2 staples with the clearest, cleanest signal (from notebook 03).
# - **Geography:** country-level for the primary story + regional aggregates for context.
# - **Time:** 2000–latest for modeling (coverage is best), full series for context charts.

# %%
print("Next step: lock the primary hypothesis, then build the modeling notebook.")
