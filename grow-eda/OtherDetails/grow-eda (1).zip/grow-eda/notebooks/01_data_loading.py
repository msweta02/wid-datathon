# %% [markdown]
# # 01 — Data Loading & Inventory (bulk CSV)
#
# Goal: load the three GROW datasets from the FAOSTAT **bulk downloads** (no account),
# confirm they melt to long format correctly, and inventory what's inside — areas,
# items, elements, year coverage — before diving into analysis.
#
# **Setup:** extract each bulk zip so the `_All_Data.csv` files sit in `data/raw/`
# (or leave them in Downloads — the loader also checks `~/Downloads/<name>_All_Data/`).

# %%
import sys
from pathlib import Path
sys.path.append(str(Path.cwd().parent if Path.cwd().name == "notebooks" else Path.cwd()))

import pandas as pd
from src.load import load_dataset, load_codes, GROW_DATASETS

pd.set_option("display.max_columns", 40)
pd.set_option("display.width", 160)

# %% [markdown]
# ## 1. Load all three (first run melts wide→long and caches to parquet; later runs are instant)

# %%
qcl = load_dataset("QCL")
qi  = load_dataset("QI")
qv  = load_dataset("QV")
for name, df in [("QCL", qcl), ("QI", qi), ("QV", qv)]:
    print(f"{name}: {df.shape[0]:,} rows, years {df['year'].min()}–{df['year'].max()}")

# %% [markdown]
# ## 2. What do the columns look like?

# %%
qcl.head()

# %% [markdown]
# ## 3. Inventory QCL — the richest dataset
# What elements, how many items, how many areas vs aggregates?

# %%
print("Elements:")
print(qcl[["Element Code", "Element", "Unit"]].drop_duplicates().to_string(index=False))

# %%
items = qcl[["Item Code", "Item"]].drop_duplicates()
print(f"QCL items: {len(items)}")
items.head(30)

# %%
areas = qcl[["Area Code", "Area"]].drop_duplicates()
agg = areas[pd.to_numeric(areas["Area Code"], errors="coerce") >= 5000]
print(f"Total areas: {len(areas)} | aggregates (code>=5000): {len(agg)}")
print("Aggregates include:", agg["Area"].head(15).tolist())

# %% [markdown]
# ## 4. Same quick inventory for QI and QV elements

# %%
print("QI elements:")
print(qi[["Element Code", "Element", "Unit"]].drop_duplicates().to_string(index=False))
print("\nQV elements:")
print(qv[["Element Code", "Element", "Unit"]].drop_duplicates().to_string(index=False))

# %% [markdown]
# ## 5. Peek at the shipped lookup tables (optional reference)
# ItemCodes flags which items are aggregates; Elements confirms units.

# %%
try:
    item_codes = load_codes("QCL", "ItemCodes")
    print("ItemCodes sample:")
    print(item_codes.head())
except FileNotFoundError as e:
    print("(ItemCodes CSV not extracted — optional)", e)

# %% [markdown]
# **Checkpoint:** all three load and melt cleanly, coverage runs 1961→recent.
# Note the exact Element Codes above — you'll filter on them in notebooks 02–04.
# Move to `02_top_producers.py`.
