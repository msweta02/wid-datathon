"""
Reusable plotting helpers. Keep notebooks thin by calling these.
"""
from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

ROOT = Path(__file__).resolve().parents[1]
FIGDIR = ROOT / "outputs" / "figures"
FIGDIR.mkdir(parents=True, exist_ok=True)

sns.set_theme(style="whitegrid", context="notebook")


def save(fig, name: str, dpi: int = 150) -> Path:
    path = FIGDIR / f"{name}.png"
    fig.savefig(path, dpi=dpi, bbox_inches="tight")
    print(f"figure -> {path}")
    return path


def trend_over_time(df: pd.DataFrame, year_col: str, value_col: str,
                    group_col: str | None = None, title: str = "",
                    ylabel: str = "", top_n: int | None = None, ax=None):
    """
    Line plot of a value over years, optionally split by group (e.g. region, crop).
    If top_n is set and group_col given, keep only the top_n groups by final-year value.
    """
    if ax is None:
        fig, ax = plt.subplots(figsize=(10, 6))
    else:
        fig = ax.figure

    d = df.copy()
    if group_col and top_n:
        last_year = d[year_col].max()
        top = (
            d[d[year_col] == last_year]
            .groupby(group_col)[value_col].sum()
            .nlargest(top_n).index
        )
        d = d[d[group_col].isin(top)]

    if group_col:
        for key, sub in d.groupby(group_col):
            agg = sub.groupby(year_col)[value_col].sum()
            ax.plot(agg.index, agg.values, label=str(key), linewidth=1.8)
        ax.legend(bbox_to_anchor=(1.02, 1), loc="upper left", fontsize=8)
    else:
        agg = d.groupby(year_col)[value_col].sum()
        ax.plot(agg.index, agg.values, linewidth=2)

    ax.set_title(title or f"{value_col} over time")
    ax.set_xlabel("Year")
    ax.set_ylabel(ylabel or value_col)
    return fig, ax


def missingness_heatmap(df: pd.DataFrame, index_col: str, year_col: str,
                        value_col: str, title: str = "Data coverage", ax=None):
    """
    Heatmap of value presence (index x year). Great for the feasibility notebook —
    shows which countries/crops have sparse coverage.
    """
    pivot = df.pivot_table(index=index_col, columns=year_col,
                           values=value_col, aggfunc="size")
    presence = pivot.notna().astype(int)
    if ax is None:
        fig, ax = plt.subplots(figsize=(14, max(4, len(presence) * 0.25)))
    else:
        fig = ax.figure
    sns.heatmap(presence, cmap="Greens", cbar=False, ax=ax)
    ax.set_title(title)
    return fig, ax


def flag_composition(df: pd.DataFrame, flag_col: str = "flag",
                     year_col: str = "year", title: str = "Flag composition over time", ax=None):
    """Stacked area of flag share by year — shows how much data is estimated/imputed."""
    d = df.copy()
    d[flag_col] = d[flag_col].fillna("")
    share = (
        d.groupby([year_col, flag_col]).size()
        .groupby(level=0).apply(lambda s: s / s.sum())
        .unstack(fill_value=0)
    )
    if ax is None:
        fig, ax = plt.subplots(figsize=(10, 5))
    else:
        fig = ax.figure
    share.plot.area(ax=ax, linewidth=0)
    ax.set_title(title)
    ax.set_ylabel("share of records")
    ax.legend(bbox_to_anchor=(1.02, 1), loc="upper left", fontsize=8)
    return fig, ax
